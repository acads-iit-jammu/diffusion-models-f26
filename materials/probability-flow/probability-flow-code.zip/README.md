# Probability-flow teaching code (Draft)

Companion to Lecture Notes 15–17. Data time is 0; terminal time is 1.

## Setup

Create a Python 3.12 environment and install `requirements.txt`. Open the
notebooks with that environment as the kernel in a Jupyter-compatible editor.
The notebooks are self-contained mini-tutorials with LaTeX derivations, explanations before the code, interpretations of results, exercises, and executed outputs. No GPU or
external data is needed for the scalar experiments.

Run notebooks 01–04 in order. Notebook 05 is the self-contained Part 6 worked example, with its own linear VP schedule, training loop, and inference diagnostics. Notebook 03 optionally writes `toy-noise.pt`;
Notebook 04 trains independently if it cannot find that checkpoint.

`verification.json` records the local CPU run and its quantitative checks.
`tested-versions.txt` records the versions used. Minor platform-dependent
numerical and timing differences are expected.

## Image example

`python image-model/ddpm_mnist.py smoke --checkpoint runs/smoke.pt`

This checks the complete model, loss gradient, schedule identities,
checkpoint round trip, and both samplers using synthetic input.

`python image-model/ddpm_mnist.py train --device cpu --updates 10000`

Training downloads MNIST if needed. Use `--device cuda` for a CUDA GPU.
The default writes `runs/mnist-ddpm.pt`; use a different path for independent
runs. This command starts fresh; it does not resume training automatically.

`python image-model/ddpm_mnist.py sample --method ddpm --output runs/ddpm.png`

`python image-model/ddpm_mnist.py sample --method ddim --ddim-steps 50 --output runs/ddim.png`

Raw tensors are saved alongside display images. Full MNIST training and
image-quality evaluation have not been run for the draft. A successful smoke
check does not establish image quality. See Lecture 16 for the full recipe.

## Browser reading copies

A full `quarto render` runs the notebook renderer through
`scripts/render-notebooks.ts`. The nested Quarto configuration renders saved
notebook outputs without executing the training cells. Lecture 15 links to
both the rendered HTML and the downloadable notebook sources.

`quarto preview` reuses those HTML pages rather than rebuilding the nested
notebook project on each preview event. If notebook HTML is missing, the hook
creates it once. This prevents generated files from causing a rebuild loop.

After editing notebook code, rerun and save the notebook to update its outputs.
Then run `quarto render` to refresh its reading page and the course site.
Ordinary lecture edits still update through live preview.
